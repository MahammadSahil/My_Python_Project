import pickle
import streamlit as st

model = pickle.load(open("Data.pkl","rb"))

def fun():
    st.title("Predicting the Salary of a employee based on his experience")
    area = st.number_input("Enter the year of experience of the employee")
    pred = st.button("Start")
    if pred:
        op = model.predict([["Data"]])
        st.write("The Predicted Salary of the Employee is : ",op[0])


fun()